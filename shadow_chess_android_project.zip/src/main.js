import { Chess } from 'chess.js';
import './style.css';

const app = document.querySelector('#app');
const game = new Chess();
let mode = 'friend';
let flipped = false;
let selected = null;
let legalTargets = [];
let thinking = false;
let lastMove = null;
let history = [];

const glyphs = { w:{k:'♔',q:'♕',r:'♖',b:'♗',n:'♘',p:'♙'}, b:{k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'} };
const pieceName = {q:'Queen',r:'Rook',b:'Bishop',n:'Knight'};
const files = 'abcdefgh';

function statusText() {
  if (game.isCheckmate()) return `Checkmate — ${game.turn()==='w'?'Black':'White'} wins`;
  if (game.isStalemate()) return 'Draw — stalemate';
  if (game.isThreefoldRepetition()) return 'Draw — threefold repetition';
  if (game.isInsufficientMaterial()) return 'Draw — insufficient material';
  if (game.isDraw()) return 'Draw';
  return `${game.turn()==='w'?'White':'Black'} to move${game.isCheck()?' · Check':''}`;
}
function ended() { return game.isGameOver(); }
function squareName(sq) { return sq; }
function render() {
  const board = flipped ? [...files].reverse().flatMap(f=>[1,2,3,4,5,6,7,8].map(r=>f+r)) : [...Array(8)].flatMap((_,r)=>[...files].map(f=>f+(8-r)));
  const checkedKing = game.isCheck() ? (game.turn()==='w'?'w':'b') : null;
  const kingSquare = checkedKing ? findKing(checkedKing) : null;
  app.innerHTML = `
    <main class="shell">
      <header class="topbar">
        <div class="brand"><div class="brand-mark">♞</div><div><h1>SHADOW CHESS</h1><p>Think ahead. Play smart.</p></div></div>
        <button class="icon-btn" id="flip" aria-label="Flip board" title="Flip board">⇅</button>
      </header>
      <section class="game-head">
        <div><span class="eyebrow">CURRENT GAME</span><div class="status">${statusText()}</div></div>
        <span class="turn-dot ${game.turn()==='w'?'white':'black'}"></span>
      </section>
      <section class="board-wrap"><div class="board" role="grid" aria-label="Chess board">
        ${board.map((sq)=>{
          const file=files.indexOf(sq[0]), rank=Number(sq[1]);
          const piece=game.get(sq), isLight=(file+(rank-1))%2===1;
          const move=lastMove&&(lastMove.from===sq||lastMove.to===sq);
          const target=legalTargets.includes(sq);
          const selectedNow=selected===sq;
          return `<button class="square ${isLight?'light':'dark'} ${selectedNow?'selected':''} ${move?'last-move':''} ${sq===kingSquare?'in-check':''}" data-square="${sq}" aria-label="${sq}${piece?` ${piece.color==='w'?'white':'black'} ${piece.type}`:''}">
            ${target?`<span class="target ${piece?'capture':''}"></span>`:''}
            ${piece?`<span class="piece ${piece.color==='w'?'white-piece':'black-piece'}">${glyphs[piece.color][piece.type]}</span>`:''}
            ${file===0?`<span class="coord rank">${rank}</span>`:''}
            ${rank===(flipped?8:1)?`<span class="coord file">${sq[0]}</span>`:''}
          </button>`;
        }).join('')}
      </div></section>
      <section class="controls">
        <div class="control-row">
          <button class="primary" id="new-game">New game</button>
          <button class="secondary" id="undo" ${history.length===0?'disabled':''}>↶ Undo</button>
          <button class="secondary" id="hint" ${ended()||thinking?'disabled':''}>Hint</button>
        </div>
        <div class="control-row modes">
          <button class="${mode==='friend'?'mode-active':''}" data-mode="friend">2 Players</button>
          <button class="${mode==='computer'?'mode-active':''}" data-mode="computer">vs Computer</button>
        </div>
      </section>
      <section class="lower">
        <div class="panel">
          <div class="panel-title">MOVE HISTORY <span>${history.length} moves</span></div>
          <div class="move-list" id="move-list">${history.length?history.map((m,i)=>`<span class="move"><b>${Math.floor(i/2)+1}${i%2===0?'.':'...'}</b> ${m.san}</span>`).join(''):'<span class="empty">Your moves will appear here.</span>'}</div>
        </div>
        <div class="panel tips"><div class="panel-title">HOW TO PLAY</div><p>Tap one of your pieces, then tap a highlighted square. Legal moves are enforced automatically.</p></div>
      </section>
      <footer>Shadow Chess · Local game · No account needed</footer>
    </main>
    <div class="modal hidden" id="promotion-modal"><div class="modal-card"><h2>Promote pawn</h2><p>Choose your piece</p><div class="promotion-options">${['q','r','b','n'].map(p=>`<button data-promo="${p}">${glyphs.w[p]}<small>${pieceName[p]}</small></button>`).join('')}</div></div></div>
    <div class="toast hidden" id="toast"></div>`;
  document.querySelectorAll('.square').forEach(btn=>btn.addEventListener('click',()=>onSquare(btn.dataset.square)));
  document.querySelector('#new-game').onclick=()=>{game.reset();history=[];lastMove=null;selected=null;legalTargets=[];thinking=false;render();};
  document.querySelector('#undo').onclick=undo;
  document.querySelector('#flip').onclick=()=>{flipped=!flipped;render();};
  document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;game.reset();history=[];lastMove=null;selected=null;legalTargets=[];thinking=false;render();});
  document.querySelector('#hint').onclick=showHint;
  document.querySelectorAll('[data-promo]').forEach(b=>b.onclick=()=>completePromotion(b.dataset.promo));
}
function findKing(color) {
  for(const rank of '87654321') for(const file of files) {const sq=file+rank,p=game.get(sq);if(p?.type==='k'&&p.color===color)return sq;}
  return null;
}
function onSquare(sq) {
  if(ended()||thinking||(mode==='computer'&&game.turn()==='b')) return;
  const piece=game.get(sq);
  if(selected && legalTargets.includes(sq)) {
    const moving=game.get(selected);
    if(moving?.type==='p'&&(sq[1]==='8'||sq[1]==='1')) { showPromotion(selected,sq); return; }
    makeMove(selected,sq); return;
  }
  if(piece&&piece.color===game.turn()) {
    selected=sq;legalTargets=game.moves({square:sq,verbose:true}).map(m=>m.to);render();
  } else {selected=null;legalTargets=[];render();}
}
let pendingPromotion=null;
function showPromotion(from,to) {
  pendingPromotion={from,to};
  document.querySelector('#promotion-modal').classList.remove('hidden');
}
function completePromotion(promotion) {
  if(!pendingPromotion)return;
  const {from,to}=pendingPromotion;pendingPromotion=null;
  document.querySelector('#promotion-modal').classList.add('hidden');
  makeMove(from,to,promotion);
}
function makeMove(from,to,promotion) {
  try {
    const move=game.move({from,to,promotion});
    if(!move)return;
    history.push(move);lastMove={from,to};selected=null;legalTargets=[];
    render();
    if(mode==='computer'&&!ended()&&game.turn()==='b') setTimeout(computerMove,350);
  } catch(e) { showToast('That move is not legal.'); }
}
function computerMove() {
  if(ended())return;
  thinking=true;
  const moves=game.moves({verbose:true});
  const scored=moves.map(m=>({m,score:(m.captured?({q:9,r:5,b:3,n:3,p:1}[m.captured]||0):0)+(m.san.includes('#')?1000:0)+(m.san.includes('+')?0.7:0)+Math.random()*0.25}));
  scored.sort((a,b)=>b.score-a.score);
  const pick=scored[0]?.m;
  if(pick){const move=game.move({from:pick.from,to:pick.to,promotion:pick.promotion||'q'});history.push(move);lastMove={from:pick.from,to:pick.to};}
  thinking=false;render();
}
function undo() {
  if(!history.length)return;
  game.undo();history.pop();
  if(mode==='computer'&&game.turn()==='b'&&history.length){game.undo();history.pop();}
  lastMove=null;selected=null;legalTargets=[];thinking=false;render();
}
function showHint() {
  const moves=game.moves({verbose:true});if(!moves.length)return;
  const m=moves[Math.floor(Math.random()*moves.length)];
  showToast(`Try ${m.from} → ${m.to}`);
}
let toastTimer;
function showToast(msg) {
  const el=document.querySelector('#toast');el.textContent=msg;el.classList.remove('hidden');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),2200);
}
render();
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));