# Shadow Chess

Mobile-first chess app built with Vite, chess.js, and Capacitor.

## Features
- Legal chess moves enforced by chess.js
- Check, checkmate, stalemate, draw detection
- Castling, en passant, and promotion selection
- Two-player local mode and a simple computer opponent
- Undo, new game, board flip, move history
- PWA install support and Android packaging with Capacitor

## Run locally
```bash
npm install
npm run dev
```

## Build the web app
```bash
npm run build
```

## Build an Android APK
You need Android Studio / Android SDK on a computer, or use the included GitHub Actions workflow.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
```
Open the generated `android` folder in Android Studio and build:
**Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The APK is generated at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload this project.
2. Push the `main` branch.
3. Open the **Actions** tab and run **Build Android APK**.
4. Download the `shadow-chess-debug-apk` artifact from the completed workflow.
5. Extract the APK and install it on your Android phone.

The workflow builds a debug APK. It is suitable for personal testing, not Play Store publishing.
